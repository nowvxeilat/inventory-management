const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const OrderController = require('../controllers/OrderController');
const { auth, isAdmin } = require('../middleware/auth');
const validate = require('../middleware/validate');

router.post('/',
  auth,
  [
    body('shippingAddress').isObject(),
    body('shippingAddress.street').notEmpty(),
    body('shippingAddress.city').notEmpty(),
    body('shippingAddress.state').notEmpty(),
    body('shippingAddress.zipCode').notEmpty(),
    body('shippingAddress.country').notEmpty()
  ],
  validate,
  OrderController.create
);

router.get('/', auth, OrderController.getOrders);
router.get('/:id', auth, OrderController.getOrder);

router.patch('/:id/status',
  auth,
  isAdmin,
  [
    body('status').isIn(['pending', 'processing', 'shipped', 'delivered', 'cancelled'])
  ],
  validate,
  OrderController.updateOrderStatus
);

router.post('/webhook', OrderController.handleStripeWebhook);

module.exports = router;