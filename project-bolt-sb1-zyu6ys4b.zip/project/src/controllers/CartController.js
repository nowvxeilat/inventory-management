const Cart = require('../models/Cart');
const Product = require('../models/Product');
const logger = require('../config/logger');

class CartController {
  static async getCart(req, res) {
    try {
      let cart = await Cart.findOne({ user: req.user._id })
        .populate('items.product');
      
      if (!cart) {
        cart = await Cart.create({ user: req.user._id, items: [] });
      }
      
      res.json(cart);
    } catch (error) {
      logger.error('Cart fetch error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  static async addItem(req, res) {
    try {
      const { productId, quantity } = req.body;
      
      const product = await Product.findById(productId);
      if (!product) {
        return res.status(404).json({ error: 'Product not found' });
      }

      let cart = await Cart.findOne({ user: req.user._id });
      if (!cart) {
        cart = new Cart({ user: req.user._id, items: [] });
      }

      const itemIndex = cart.items.findIndex(
        item => item.product.toString() === productId
      );

      if (itemIndex > -1) {
        cart.items[itemIndex].quantity += quantity;
      } else {
        cart.items.push({ product: productId, quantity });
      }

      cart.lastUpdated = new Date();
      await cart.save();
      
      res.json(cart);
    } catch (error) {
      logger.error('Cart update error:', error);
      res.status(400).json({ error: error.message });
    }
  }

  static async updateItem(req, res) {
    try {
      const { productId, quantity } = req.body;
      
      const cart = await Cart.findOne({ user: req.user._id });
      if (!cart) {
        return res.status(404).json({ error: 'Cart not found' });
      }

      const itemIndex = cart.items.findIndex(
        item => item.product.toString() === productId
      );

      if (itemIndex === -1) {
        return res.status(404).json({ error: 'Item not found in cart' });
      }

      if (quantity <= 0) {
        cart.items.splice(itemIndex, 1);
      } else {
        cart.items[itemIndex].quantity = quantity;
      }

      cart.lastUpdated = new Date();
      await cart.save();
      
      res.json(cart);
    } catch (error) {
      logger.error('Cart update error:', error);
      res.status(400).json({ error: error.message });
    }
  }

  static async removeItem(req, res) {
    try {
      const { productId } = req.params;
      
      const cart = await Cart.findOne({ user: req.user._id });
      if (!cart) {
        return res.status(404).json({ error: 'Cart not found' });
      }

      cart.items = cart.items.filter(
        item => item.product.toString() !== productId
      );

      cart.lastUpdated = new Date();
      await cart.save();
      
      res.json(cart);
    } catch (error) {
      logger.error('Cart update error:', error);
      res.status(400).json({ error: error.message });
    }
  }

  static async clearCart(req, res) {
    try {
      const cart = await Cart.findOne({ user: req.user._id });
      if (!cart) {
        return res.status(404).json({ error: 'Cart not found' });
      }

      cart.items = [];
      cart.lastUpdated = new Date();
      await cart.save();
      
      res.json({ message: 'Cart cleared successfully' });
    } catch (error) {
      logger.error('Cart clear error:', error);
      res.status(500).json({ error: error.message });
    }
  }
}