const Order = require('../models/Order');
const Cart = require('../models/Cart');
const Product = require('../models/Product');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const logger = require('../config/logger');

class OrderController {
  static async create(req, res) {
    try {
      const cart = await Cart.findOne({ user: req.user._id }).populate('items.product');
      if (!cart || cart.items.length === 0) {
        return res.status(400).json({ error: 'Cart is empty' });
      }

      // Calculate total and check inventory
      let totalAmount = 0;
      const orderItems = [];
      
      for (const item of cart.items) {
        const product = item.product;
        if (product.inventory < item.quantity) {
          return res.status(400).json({ 
            error: `Insufficient inventory for product: ${product.name}` 
          });
        }

        totalAmount += product.price * item.quantity;
        orderItems.push({
          product: product._id,
          quantity: item.quantity,
          price: product.price
        });
      }

      // Create Stripe payment intent
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(totalAmount * 100), // Convert to cents
        currency: 'usd',
        metadata: { userId: req.user._id.toString() }
      });

      const order = new Order({
        user: req.user._id,
        items: orderItems,
        totalAmount,
        shippingAddress: req.body.shippingAddress,
        paymentId: paymentIntent.id
      });

      await order.save();

      // Update inventory
      for (const item of cart.items) {
        await Product.findByIdAndUpdate(
          item.product._id,
          { $inc: { inventory: -item.quantity } }
        );
      }

      // Clear cart
      cart.items = [];
      await cart.save();

      res.status(201).json({
        order,
        clientSecret: paymentIntent.client_secret
      });
    } catch (error) {
      logger.error('Order creation error:', error);
      res.status(500).json({ error: 'Error creating order' });
    }
  }

  static async getOrders(req, res) {
    try {
      const orders = await Order.find({ user: req.user._id })
        .populate('items.product')
        .sort({ createdAt: -1 });
      res.json(orders);
    } catch (error) {
      logger.error('Order fetch error:', error);
      res.status(500).json({ error: 'Error fetching orders' });
    }
  }

  static async getOrder(req, res) {
    try {
      const order = await Order.findOne({
        _id: req.params.id,
        user: req.user._id
      }).populate('items.product');

      if (!order) {
        return res.status(404).json({ error: 'Order not found' });
      }

      res.json(order);
    } catch (error) {
      logger.error('Order fetch error:', error);
      res.status(500).json({ error: 'Error fetching order' });
    }
  }

  static async updateOrderStatus(req, res) {
    try {
      const { status } = req.body;
      const order = await Order.findById(req.params.id);

      if (!order) {
        return res.status(404).json({ error: 'Order not found' });
      }

      order.status = status;
      await order.save();

      res.json(order);
    } catch (error) {
      logger.error('Order update error:', error);
      res.status(500).json({ error: 'Error updating order' });
    }
  }

  static async handleStripeWebhook(req, res) {
    const sig = req.headers['stripe-signature'];
    let event;

    try {
      event = stripe.webhooks.constructEvent(
        req.body,
        sig,
        process.env.STRIPE_WEBHOOK_SECRET
      );
    } catch (err) {
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    if (event.type === 'payment_intent.succeeded') {
      const paymentIntent = event.data.object;
      await Order.findOneAndUpdate(
        { paymentId: paymentIntent.id },
        { 
          paymentStatus: 'completed',
          status: 'processing'
        }
      );
    }

    res.json({ received: true });
  }
}