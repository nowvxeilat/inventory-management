const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const CategoryController = require('../controllers/CategoryController');
const { auth, isAdmin } = require('../middleware/auth');
const validate = require('../middleware/validate');

router.get('/', CategoryController.getAll);
router.get('/:id', CategoryController.getOne);

router.post('/',
  auth,
  isAdmin,
  [
    body('name').trim().notEmpty(),
    body('description').optional().trim(),
    body('parent').optional().isMongoId()
  ],
  validate,
  CategoryController.create
);

router.put('/:id',
  auth,
  isAdmin,
  [
    body('name').optional().trim().notEmpty(),
    body('description').optional().trim(),
    body('parent').optional().isMongoId()
  ],
  validate,
  CategoryController.update
);

router.delete('/:id', auth, isAdmin, CategoryController.delete);

module.exports = router;