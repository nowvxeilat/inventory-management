const Product = require('../models/Product');
const Category = require('../models/Category');

class SearchService {
  static async searchProducts({
    query = '',
    category = null,
    minPrice = null,
    maxPrice = null,
    inStock = false,
    sortBy = 'createdAt',
    sortOrder = 'desc',
    page = 1,
    limit = 10
  }) {
    const searchQuery = {};
    
    // Text search
    if (query) {
      searchQuery.$text = { $search: query };
    }

    // Category filter
    if (category) {
      searchQuery.category = category;
    }

    // Price range filter
    if (minPrice !== null || maxPrice !== null) {
      searchQuery.price = {};
      if (minPrice !== null) searchQuery.price.$gte = minPrice;
      if (maxPrice !== null) searchQuery.price.$lte = maxPrice;
    }

    // Stock filter
    if (inStock) {
      searchQuery.inventory = { $gt: 0 };
    }

    // Build sort object
    const sortOptions = {};
    sortOptions[sortBy] = sortOrder === 'desc' ? -1 : 1;

    // Execute search with pagination
    const products = await Product.find(searchQuery)
      .populate('category')
      .sort(sortOptions)
      .skip((page - 1) * limit)
      .limit(limit);

    const total = await Product.countDocuments(searchQuery);

    return {
      products,
      total,
      totalPages: Math.ceil(total / limit),
      currentPage: page
    };
  }
}