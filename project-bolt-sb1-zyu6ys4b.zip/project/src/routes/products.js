const express = require('express');
const router = express.Router();
const { body, query } = require('express-validator');
const ProductController = require('../controllers/ProductController');
const { auth, isAdmin } = require('../middleware/auth');
const validate = require('../middleware/validate');

// Search and filter endpoints
router.get('/search',
  [
    query('query').optional().trim(),
    query('category').optional().isMongoId(),
    query('minPrice').optional().isFloat({ min: 0 }),
    query('maxPrice').optional().isFloat({ min: 0 }),
    query('inStock').optional().isBoolean(),
    query('sortBy').optional().isIn(['createdAt', 'price', 'name']),
    query('sortOrder').optional().isIn(['asc', 'desc']),
    query('page').optional().isInt({ min: 1 }),
    query('limit').optional().isInt({ min: 1, max: 100 })
  ],
  validate,
  ProductController.search
);

// Inventory management endpoints
router.patch('/:id/inventory',
  auth,
  isAdmin,
  [
    body('quantity').isInt({ min: 1 }),
    body('operation').isIn(['add', 'subtract'])
  ],
  validate,
  ProductController.updateInventory
);

router.get('/inventory/report',
  auth,
  isAdmin,
  ProductController.getInventoryReport
);

// ... (keep existing routes)

module.exports = router;