const express = require('express');
const router = express.Router();
const { setupTestData } = require('../services/testDataService');

router.get('/setup', setupTestData.createTestUser);
router.get('/products', setupTestData.createTestProducts);

module.exports = router;