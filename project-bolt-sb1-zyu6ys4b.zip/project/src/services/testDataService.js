const User = require('../models/User');
const Product = require('../models/Product');
const Category = require('../models/Category');
const logger = require('../config/logger');

const setupTestData = {
  async createTestUser(req, res) {
    try {
      const testUser = await User.findOne({ email: 'test@example.com' });
      if (!testUser) {
        await User.create({
          email: 'test@example.com',
          password: 'password123',
          profile: {
            firstName: 'Test',
            lastName: 'User'
          }
        });
      }
      res.json({ message: 'Test user created successfully' });
    } catch (error) {
      logger.error('Test user creation error:', error);
      res.status(500).json({ error: error.message });
    }
  },

  async createTestProducts(req, res) {
    try {
      let category = await Category.findOne({ name: 'Electronics' });
      if (!category) {
        category = await Category.create({
          name: 'Electronics',
          description: 'Electronic devices and gadgets',
          slug: 'electronics'
        });
      }

      const products = await Product.find();
      if (products.length === 0) {
        await Product.create([
          {
            name: 'Smartphone',
            description: 'Latest model smartphone with great features',
            price: 699.99,
            category: category._id,
            inventory: 50,
            images: [{ url: 'https://via.placeholder.com/150', alt: 'Smartphone' }]
          },
          {
            name: 'Laptop',
            description: 'Powerful laptop for work and gaming',
            price: 1299.99,
            category: category._id,
            inventory: 30,
            images: [{ url: 'https://via.placeholder.com/150', alt: 'Laptop' }]
          },
          {
            name: 'Wireless Earbuds',
            description: 'High-quality wireless earbuds with noise cancellation',
            price: 199.99,
            category: category._id,
            inventory: 100,
            images: [{ url: 'https://via.placeholder.com/150', alt: 'Earbuds' }]
          }
        ]);
      }

      const allProducts = await Product.find().populate('category');
      res.json({ products: allProducts });
    } catch (error) {
      logger.error('Test products creation error:', error);
      res.status(500).json({ error: error.message });
    }
  }
};

module.exports = { setupTestData };