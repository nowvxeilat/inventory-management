const jwt = require('jsonwebtoken');
const User = require('../models/User');
const logger = require('../config/logger');

class AuthController {
  static async register(req, res) {
    try {
      const { email, password, firstName, lastName } = req.body;

      const existingUser = await User.findOne({ email });
      if (existingUser) {
        return res.status(400).json({ error: 'Email already registered' });
      }

      const user = new User({
        email,
        password,
        profile: { firstName, lastName }
      });

      await user.save();

      const token = jwt.sign(
        { userId: user._id },
        process.env.JWT_SECRET || 'your-secret-key',
        { expiresIn: '24h' }
      );

      res.status(201).json({ user, token });
    } catch (error) {
      logger.error('Registration error:', error);
      res.status(500).json({ error: 'Error registering user' });
    }
  }

  static async login(req, res) {
    try {
      const { email, password } = req.body;
      const user = await User.findOne({ email });

      if (!user || !(await user.comparePassword(password))) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }

      const token = jwt.sign(
        { userId: user._id },
        process.env.JWT_SECRET || 'your-secret-key',
        { expiresIn: '24h' }
      );

      res.json({ user, token });
    } catch (error) {
      logger.error('Login error:', error);
      res.status(500).json({ error: 'Error logging in' });
    }
  }
}

module.exports = AuthController;