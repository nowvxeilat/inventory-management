// API URL - Use relative path for same-origin requests
const API_URL = '';

let token = localStorage.getItem('token');
let cart = { items: [] };

// DOM Elements
const productsContainer = document.getElementById('products');
const searchInput = document.getElementById('searchInput');
const cartBtn = document.getElementById('cartBtn');
const loginBtn = document.getElementById('loginBtn');
const cartModal = document.getElementById('cartModal');
const loginModal = document.getElementById('loginModal');
const closeCartBtn = document.getElementById('closeCartBtn');
const closeLoginBtn = document.getElementById('closeLoginBtn');
const loginForm = document.getElementById('loginForm');
const cartItems = document.getElementById('cartItems');
const cartTotal = document.getElementById('cartTotal');
const cartCount = document.getElementById('cartCount');
const checkoutBtn = document.getElementById('checkoutBtn');

// Event Listeners
searchInput.addEventListener('input', debounce(searchProducts, 300));
cartBtn.addEventListener('click', toggleCart);
loginBtn.addEventListener('click', toggleLogin);
closeCartBtn.addEventListener('click', toggleCart);
closeLoginBtn.addEventListener('click', toggleLogin);
loginForm.addEventListener('submit', handleLogin);
checkoutBtn.addEventListener('click', handleCheckout);

// Initialize
loadProducts();
if (token) {
    loadCart();
    loginBtn.textContent = 'Logout';
}

// Functions
async function loadProducts(searchQuery = '') {
    try {
        const response = await fetch(`/api/test/products`);
        const data = await response.json();
        displayProducts(data.products);
    } catch (error) {
        console.error('Error loading products:', error);
    }
}

function displayProducts(products) {
    productsContainer.innerHTML = products.map(product => `
        <div class="bg-white p-4 rounded-lg shadow">
            <img src="${product.images[0].url}" alt="${product.images[0].alt}" class="w-full h-48 object-cover mb-4">
            <h3 class="text-lg font-semibold">${product.name}</h3>
            <p class="text-gray-600">${product.description}</p>
            <div class="mt-4 flex justify-between items-center">
                <span class="text-lg font-bold">$${product.price}</span>
                <button onclick="addToCart('${product._id}')" 
                        class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">
                    Add to Cart
                </button>
            </div>
        </div>
    `).join('');
}

async function addToCart(productId) {
    if (!token) {
        alert('Please login first');
        return;
    }

    try {
        const response = await fetch(`/api/cart/items`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                productId,
                quantity: 1
            })
        });

        if (response.ok) {
            loadCart();
        }
    } catch (error) {
        console.error('Error adding to cart:', error);
    }
}

async function loadCart() {
    try {
        const response = await fetch(`/api/cart`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        cart = await response.json();
        updateCartDisplay();
    } catch (error) {
        console.error('Error loading cart:', error);
    }
}

function updateCartDisplay() {
    cartCount.textContent = cart.items.length;
    
    if (cart.items.length === 0) {
        cartItems.innerHTML = '<p>Your cart is empty</p>';
        cartTotal.textContent = '$0.00';
        return;
    }

    let total = 0;
    cartItems.innerHTML = cart.items.map(item => {
        total += item.product.price * item.quantity;
        return `
            <div class="flex justify-between items-center">
                <div>
                    <h4 class="font-semibold">${item.product.name}</h4>
                    <p class="text-sm text-gray-600">$${item.product.price} x ${item.quantity}</p>
                </div>
                <button onclick="removeFromCart('${item.product._id}')" 
                        class="text-red-500 hover:text-red-700">
                    Remove
                </button>
            </div>
        `;
    }).join('');

    cartTotal.textContent = `$${total.toFixed(2)}`;
}

async function removeFromCart(productId) {
    try {
        const response = await fetch(`/api/cart/items/${productId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (response.ok) {
            loadCart();
        }
    } catch (error) {
        console.error('Error removing from cart:', error);
    }
}

async function handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;

    try {
        const response = await fetch(`/api/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, password })
        });

        const data = await response.json();
        if (response.ok) {
            token = data.token;
            localStorage.setItem('token', token);
            loginBtn.textContent = 'Logout';
            toggleLogin();
            loadCart();
        } else {
            alert(data.error);
        }
    } catch (error) {
        console.error('Login error:', error);
    }
}

async function handleCheckout() {
    if (cart.items.length === 0) {
        alert('Your cart is empty');
        return;
    }

    try {
        const response = await fetch(`/api/orders`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                shippingAddress: {
                    street: '123 Main St',
                    city: 'Example City',
                    state: 'EX',
                    zipCode: '12345',
                    country: 'US'
                }
            })
        });

        const data = await response.json();
        if (response.ok) {
            alert('Order placed successfully!');
            loadCart();
            toggleCart();
        } else {
            alert(data.error);
        }
    } catch (error) {
        console.error('Checkout error:', error);
    }
}

function toggleCart() {
    cartModal.classList.toggle('hidden');
}

function toggleLogin() {
    if (token && loginBtn.textContent === 'Logout') {
        token = null;
        localStorage.removeItem('token');
        loginBtn.textContent = 'Login';
        cart = { items: [] };
        updateCartDisplay();
        return;
    }
    loginModal.classList.toggle('hidden');
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function searchProducts() {
    loadProducts(searchInput.value);
}