const Product = require('../models/Product');
const logger = require('../config/logger');

class InventoryService {
  static async updateStock(productId, quantity, operation = 'add') {
    const update = operation === 'add' 
      ? { $inc: { inventory: quantity } }
      : { $inc: { inventory: -quantity } };

    const product = await Product.findByIdAndUpdate(
      productId,
      update,
      { new: true, runValidators: true }
    );

    if (!product) {
      throw new Error('Product not found');
    }

    // Log inventory change
    logger.info('Inventory updated', {
      productId,
      operation,
      quantity,
      newStock: product.inventory
    });

    // Check low stock threshold
    if (product.inventory <= 10) {
      logger.warn('Low stock alert', {
        productId,
        productName: product.name,
        currentStock: product.inventory
      });
    }

    return product;
  }

  static async checkStock(productId, requiredQuantity) {
    const product = await Product.findById(productId);
    
    if (!product) {
      throw new Error('Product not found');
    }

    return {
      inStock: product.inventory >= requiredQuantity,
      available: product.inventory,
      required: requiredQuantity
    };
  }

  static async getStockReport() {
    const report = await Product.aggregate([
      {
        $group: {
          _id: '$category',
          totalProducts: { $sum: 1 },
          totalStock: { $sum: '$inventory' },
          lowStock: {
            $sum: { $cond: [{ $lte: ['$inventory', 10] }, 1, 0] }
          },
          outOfStock: {
            $sum: { $cond: [{ $eq: ['$inventory', 0] }, 1, 0] }
          }
        }
      },
      {
        $lookup: {
          from: 'categories',
          localField: '_id',
          foreignField: '_id',
          as: 'category'
        }
      },
      {
        $unwind: '$category'
      }
    ]);

    return report;
  }
}