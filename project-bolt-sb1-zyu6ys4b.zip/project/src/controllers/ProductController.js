const Product = require('../models/Product');
const SearchService = require('../services/SearchService');
const InventoryService = require('../services/InventoryService');
const logger = require('../config/logger');

class ProductController {
  static async search(req, res) {
    try {
      const searchResults = await SearchService.searchProducts(req.query);
      res.json(searchResults);
    } catch (error) {
      logger.error('Product search error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  static async updateInventory(req, res) {
    try {
      const { quantity, operation } = req.body;
      const product = await InventoryService.updateStock(
        req.params.id,
        quantity,
        operation
      );
      res.json(product);
    } catch (error) {
      logger.error('Inventory update error:', error);
      res.status(400).json({ error: error.message });
    }
  }

  static async getInventoryReport(req, res) {
    try {
      const report = await InventoryService.getStockReport();
      res.json(report);
    } catch (error) {
      logger.error('Inventory report error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  // ... (keep existing CRUD methods)
}