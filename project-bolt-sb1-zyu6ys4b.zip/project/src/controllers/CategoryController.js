const Category = require('../models/Category');
const slugify = require('slugify');
const logger = require('../config/logger');

class CategoryController {
  static async create(req, res) {
    try {
      const { name, description, parent } = req.body;
      const category = new Category({
        name,
        description,
        slug: slugify(name, { lower: true }),
        parent: parent || null
      });

      await category.save();
      res.status(201).json(category);
    } catch (error) {
      logger.error('Category creation error:', error);
      res.status(400).json({ error: error.message });
    }
  }

  static async getAll(req, res) {
    try {
      const categories = await Category.find({ isActive: true })
        .populate('parent')
        .sort('name');
      res.json(categories);
    } catch (error) {
      logger.error('Category fetch error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  static async getOne(req, res) {
    try {
      const category = await Category.findById(req.params.id)
        .populate('parent');
      
      if (!category) {
        return res.status(404).json({ error: 'Category not found' });
      }
      
      res.json(category);
    } catch (error) {
      logger.error('Category fetch error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  static async update(req, res) {
    try {
      const updates = { ...req.body };
      if (updates.name) {
        updates.slug = slugify(updates.name, { lower: true });
      }

      const category = await Category.findByIdAndUpdate(
        req.params.id,
        updates,
        { new: true, runValidators: true }
      );

      if (!category) {
        return res.status(404).json({ error: 'Category not found' });
      }

      res.json(category);
    } catch (error) {
      logger.error('Category update error:', error);
      res.status(400).json({ error: error.message });
    }
  }

  static async delete(req, res) {
    try {
      const category = await Category.findByIdAndUpdate(
        req.params.id,
        { isActive: false },
        { new: true }
      );

      if (!category) {
        return res.status(404).json({ error: 'Category not found' });
      }

      res.json({ message: 'Category deleted successfully' });
    } catch (error) {
      logger.error('Category deletion error:', error);
      res.status(500).json({ error: error.message });
    }
  }
}