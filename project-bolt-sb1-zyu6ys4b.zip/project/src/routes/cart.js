const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const CartController = require('../controllers/CartController');
const { auth } = require('../middleware/auth');
const validate = require('../middleware/validate');

router.get('/', auth, CartController.getCart);

router.post('/items',
  auth,
  [
    body('productId').isMongoId(),
    body('quantity').isInt({ min: 1 })
  ],
  validate,
  CartController.addItem
);

router.put('/items',
  auth,
  [
    body('productId').isMongoId(),
    body('quantity').isInt({ min: 0 })
  ],
  validate,
  CartController.updateItem
);

router.delete('/items/:productId', auth, CartController.removeItem);
router.delete('/', auth, CartController.clearCart);

module.exports = router;