const mongoose = require('mongoose');
const { MongoMemoryServer } = require('mongodb-memory-server');
const logger = require('./logger');

let mongod = null;

const connectDB = async () => {
  try {
    if (!mongod) {
      mongod = await MongoMemoryServer.create();
      const uri = mongod.getUri();
      logger.info(`MongoDB Memory Server URI: ${uri}`);
      
      const options = {
        useNewUrlParser: true,
        useUnifiedTopology: true
      };
      
      await mongoose.connect(uri, options);
      logger.info('Connected to MongoDB Memory Server');
      
      // Create indexes after connection
      await Promise.all([
        mongoose.model('Product').createIndexes(),
        mongoose.model('Category').createIndexes(),
        mongoose.model('User').createIndexes()
      ]);
    }
  } catch (error) {
    logger.error(`MongoDB Connection Error: ${error.message}`);
    process.exit(1);
  }
};

// Clean up resources when the application exits
process.on('SIGTERM', async () => {
  try {
    if (mongod) {
      await mongod.stop();
    }
    await mongoose.connection.close();
  } catch (error) {
    logger.error(`Cleanup Error: ${error.message}`);
  }
  process.exit(0);
});

module.exports = connectDB;